function red(){
  console.log('red')
}

function yellow(){
  console.log('yellow')
}

function green(){
  console.log('green')
}

// 红灯3秒亮一次，绿灯1秒亮一次，黄灯两秒亮一次，如何让三个灯不断交替重复亮灯
